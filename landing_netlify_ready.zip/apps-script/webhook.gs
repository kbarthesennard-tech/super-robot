/**
 * ========================================
 * WEBHOOK APPS SCRIPT - FORMULAIRE ÉLIGIBILITÉ PAC
 * ========================================
 * 
 * Ce script reçoit les données du formulaire et:
 * 1. Les enregistre dans Google Sheets
 * 2. Envoie un email de confirmation au prospect
 * 3. Envoie une notification WhatsApp (via API externe)
 * 4. Envoie un email d'alerte à l'équipe
 * 
 * INSTALLATION:
 * 1. Créer un nouveau Google Sheets
 * 2. Extensions > Apps Script
 * 3. Coller ce code
 * 4. Configurer les variables ci-dessous
 * 5. Déployer > Nouvelle version web
 * 6. Copier l'URL de déploiement dans js/main.js
 */

// ========================================
// CONFIGURATION
// ========================================
const CONFIG = {
  // ID de votre Google Sheets (dans l'URL)
  SHEET_ID: 'VOTRE_SHEET_ID_ICI',
  
  // Nom de l'onglet dans Sheets
  SHEET_NAME: 'Leads',
  
  // Email de votre équipe (pour les notifications)
  TEAM_EMAIL: 'votre-email@exemple.fr',
  
  // API WhatsApp (optionnel - nécessite un service tiers comme Twilio, WhatsApp Business API, etc.)
  WHATSAPP_ENABLED: false,
  WHATSAPP_API_URL: 'https://api.exemple.com/whatsapp',
  WHATSAPP_API_KEY: 'VOTRE_CLE_API',
  WHATSAPP_PHONE_RECIPIENT: '+33612345678'
};

// ========================================
// FONCTION PRINCIPALE - RECEPTION WEBHOOK
// ========================================
function doPost(e) {
  try {
    // Parser les données JSON
    const data = JSON.parse(e.postData.contents);
    
    // Valider les données
    if (!validateData(data)) {
      return createResponse(400, 'Données invalides');
    }
    
    // 1. Enregistrer dans Google Sheets
    saveToSheet(data);
    
    // 2. Envoyer email au prospect
    sendEmailToProspect(data);
    
    // 3. Envoyer notification à l'équipe
    sendEmailToTeam(data);
    
    // 4. Envoyer WhatsApp (si activé)
    if (CONFIG.WHATSAPP_ENABLED) {
      sendWhatsApp(data);
    }
    
    return createResponse(200, 'Succès');
    
  } catch (error) {
    Logger.log('Erreur: ' + error.toString());
    return createResponse(500, 'Erreur serveur: ' + error.toString());
  }
}

// ========================================
// VALIDATION DES DONNÉES
// ========================================
function validateData(data) {
  const requiredFields = [
    'typeLogement',
    'typeResidence',
    'anciennete',
    'chauffageActuel',
    'nbPersonnes',
    'revenu',
    'codePostal',
    'nom',
    'telephone',
    'email',
    'rgpdConsent'
  ];
  
  for (const field of requiredFields) {
    if (!data[field]) {
      Logger.log('Champ manquant: ' + field);
      return false;
    }
  }
  
  // Vérifier le consentement RGPD
  if (data.rgpdConsent !== true) {
    Logger.log('Consentement RGPD manquant');
    return false;
  }
  
  // Valider l'email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(data.email)) {
    Logger.log('Email invalide');
    return false;
  }
  
  // Valider le code postal
  if (!/^[0-9]{5}$/.test(data.codePostal)) {
    Logger.log('Code postal invalide');
    return false;
  }
  
  return true;
}

// ========================================
// ENREGISTREMENT DANS GOOGLE SHEETS
// ========================================
function saveToSheet(data) {
  const ss = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME);
  
  // Créer l'onglet s'il n'existe pas
  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.SHEET_NAME);
    
    // Créer l'en-tête
    const headers = [
      'ID',
      'Date',
      'Type Logement',
      'Type Résidence',
      'Ancienneté',
      'Chauffage Actuel',
      'Nb Personnes',
      'Revenu',
      'Code Postal',
      'Région',
      'Nom',
      'Téléphone',
      'Email',
      'RGPD',
      'Source',
      'User Agent',
      'Statut',
      'Notes'
    ];
    
    sheet.appendRow(headers);
    
    // Mettre en forme l'en-tête
    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#4285F4');
    headerRange.setFontColor('#FFFFFF');
  }
  
  // Déterminer la région
  const cp = data.codePostal;
  let region = 'Hors Île-de-France';
  if (/^(75|77|78|91|92|93|94|95)/.test(cp)) {
    region = 'Île-de-France';
  } else if (/^(97|98)/.test(cp)) {
    region = 'Outre-mer';
  }
  
  // Générer un ID unique
  const id = 'LEAD_' + new Date().getTime();
  
  // Préparer les données
  const row = [
    id,
    new Date().toLocaleString('fr-FR'),
    data.typeLogement,
    data.typeResidence,
    data.anciennete,
    data.chauffageActuel,
    data.nbPersonnes,
    data.revenu,
    data.codePostal,
    region,
    data.nom,
    data.telephone,
    data.email,
    data.rgpdConsent ? 'Oui' : 'Non',
    data.source || 'Direct',
    data.userAgent || 'N/A',
    'Nouveau',
    ''
  ];
  
  // Ajouter la ligne
  sheet.appendRow(row);
  
  // Formater la nouvelle ligne
  const lastRow = sheet.getLastRow();
  const range = sheet.getRange(lastRow, 1, 1, row.length);
  range.setBorder(true, true, true, true, false, false);
  
  // Colorer selon le statut
  const statusCell = sheet.getRange(lastRow, 17); // Colonne "Statut"
  statusCell.setBackground('#FFF3CD');
  
  Logger.log('Lead enregistré: ' + id);
  
  return id;
}

// ========================================
// EMAIL AU PROSPECT
// ========================================
function sendEmailToProspect(data) {
  const subject = '✅ Demande d\'éligibilité reçue - Pompe à Chaleur';
  
  const body = `
Bonjour ${data.nom},

Nous avons bien reçu votre demande de vérification d'éligibilité pour une pompe à chaleur.

📋 RÉCAPITULATIF DE VOTRE DEMANDE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Type de logement: ${data.typeLogement}
Type de résidence: ${data.typeResidence}
Ancienneté: ${data.anciennete}
Chauffage actuel: ${data.chauffageActuel}
Nombre de personnes: ${data.nbPersonnes}
Code postal: ${data.codePostal}

📞 PROCHAINES ÉTAPES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Un de nos conseillers vous contactera sous 24h au ${data.telephone} pour:
1. Étudier votre éligibilité aux aides (MaPrimeRénov', CEE)
2. Vous présenter un devis transparent
3. Répondre à toutes vos questions

⚠️ RAPPEL IMPORTANT:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Le démarchage non sollicité est INTERDIT dans la rénovation énergétique
• Exigez un devis écrit avec les aides déduites
• Vérifiez le label RGE de l'artisan sur france-renov.gouv.fr
• Ne signez JAMAIS sous pression

📧 Besoin d'aide?
Répondez à cet email ou contactez-nous au 01 23 45 67 89

Cordialement,
L'équipe Pompe à Chaleur Éligibilité

---
Conformément au RGPD, vous pouvez exercer vos droits (accès, rectification, suppression) en répondant à cet email.
`;

  const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #0066CC 0%, #004C99 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #ffffff; padding: 30px; border: 1px solid #ddd; }
    .section { margin: 20px 0; padding: 15px; background: #f8f9fa; border-left: 4px solid #0066CC; }
    .section h3 { margin-top: 0; color: #0066CC; }
    .warning { background: #FFF3CD; border-left: 4px solid #FFC107; padding: 15px; margin: 20px 0; }
    .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
    .btn { display: inline-block; padding: 12px 24px; background: #00C853; color: white; text-decoration: none; border-radius: 5px; margin: 10px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>✅ Demande Reçue</h1>
      <p>Merci ${data.nom} !</p>
    </div>
    
    <div class="content">
      <p>Nous avons bien reçu votre demande de vérification d'éligibilité pour une pompe à chaleur.</p>
      
      <div class="section">
        <h3>📋 Récapitulatif</h3>
        <ul>
          <li><strong>Type de logement:</strong> ${data.typeLogement}</li>
          <li><strong>Type de résidence:</strong> ${data.typeResidence}</li>
          <li><strong>Ancienneté:</strong> ${data.anciennete}</li>
          <li><strong>Chauffage actuel:</strong> ${data.chauffageActuel}</li>
          <li><strong>Nombre de personnes:</strong> ${data.nbPersonnes}</li>
          <li><strong>Code postal:</strong> ${data.codePostal}</li>
        </ul>
      </div>
      
      <div class="section">
        <h3>📞 Prochaines Étapes</h3>
        <p>Un de nos conseillers vous contactera sous <strong>24h</strong> au <strong>${data.telephone}</strong> pour:</p>
        <ol>
          <li>Étudier votre éligibilité aux aides (MaPrimeRénov', CEE)</li>
          <li>Vous présenter un devis transparent</li>
          <li>Répondre à toutes vos questions</li>
        </ol>
      </div>
      
      <div class="warning">
        <h3>⚠️ Rappel Important</h3>
        <ul>
          <li>Le démarchage non sollicité est <strong>INTERDIT</strong> dans la rénovation énergétique</li>
          <li>Exigez un <strong>devis écrit</strong> avec les aides déduites</li>
          <li>Vérifiez le label <strong>RGE</strong> de l'artisan sur <a href="https://france-renov.gouv.fr/annuaires-professionnels/artisan-rge-architecte">france-renov.gouv.fr</a></li>
          <li>Ne signez <strong>JAMAIS</strong> sous pression</li>
        </ul>
      </div>
      
      <p style="text-align: center;">
        <a href="mailto:contact@votre-entreprise.fr" class="btn">Nous Contacter</a>
      </p>
    </div>
    
    <div class="footer">
      <p>Conformément au RGPD, vous pouvez exercer vos droits (accès, rectification, suppression) en répondant à cet email.</p>
      <p>&copy; 2026 - Pompe à Chaleur Éligibilité</p>
    </div>
  </div>
</body>
</html>
`;

  try {
    MailApp.sendEmail({
      to: data.email,
      subject: subject,
      body: body,
      htmlBody: htmlBody,
      name: 'Pompe à Chaleur Éligibilité'
    });
    
    Logger.log('Email prospect envoyé à: ' + data.email);
  } catch (error) {
    Logger.log('Erreur envoi email prospect: ' + error.toString());
  }
}

// ========================================
// EMAIL À L'ÉQUIPE
// ========================================
function sendEmailToTeam(data) {
  const subject = '🔔 Nouveau Lead - ' + data.nom + ' (' + data.codePostal + ')';
  
  // Déterminer la région
  const cp = data.codePostal;
  let region = 'Hors Île-de-France';
  if (/^(75|77|78|91|92|93|94|95)/.test(cp)) {
    region = 'Île-de-France';
  } else if (/^(97|98)/.test(cp)) {
    region = 'Outre-mer';
  }
  
  // Évaluation rapide d'éligibilité
  let eligibilityNote = '';
  if (data.anciennete === 'moins-2-ans') {
    eligibilityNote = '⚠️ Logement récent (< 2 ans) - Éligibilité limitée';
  } else if (data.chauffageActuel === 'fioul') {
    eligibilityNote = '✅ Chauffage fioul - Prioritaire pour les aides';
  } else if (data.revenu === 'tres-modeste' || data.revenu === 'modeste') {
    eligibilityNote = '✅ Revenus modestes - Aides maximales';
  }
  
  const body = `
NOUVEAU LEAD REÇU
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 INFORMATIONS CONTACT:
Nom: ${data.nom}
Téléphone: ${data.telephone}
Email: ${data.email}

🏠 LOGEMENT:
Type: ${data.typeLogement}
Résidence: ${data.typeResidence}
Ancienneté: ${data.anciennete}
Code Postal: ${data.codePostal}
Région: ${region}

🔥 CHAUFFAGE ACTUEL:
${data.chauffageActuel}

👨‍👩‍👧‍👦 COMPOSITION:
Nb personnes: ${data.nbPersonnes}
Revenu: ${data.revenu}

${eligibilityNote ? '\n⭐ ÉVALUATION:\n' + eligibilityNote + '\n' : ''}

📅 Reçu le: ${new Date().toLocaleString('fr-FR')}
🌐 Source: ${data.source || 'Direct'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ACTION REQUISE: Contacter sous 24h
`;

  try {
    MailApp.sendEmail({
      to: CONFIG.TEAM_EMAIL,
      subject: subject,
      body: body,
      name: 'Webhook Formulaire PAC'
    });
    
    Logger.log('Email équipe envoyé à: ' + CONFIG.TEAM_EMAIL);
  } catch (error) {
    Logger.log('Erreur envoi email équipe: ' + error.toString());
  }
}

// ========================================
// NOTIFICATION WHATSAPP (OPTIONNEL)
// ========================================
function sendWhatsApp(data) {
  if (!CONFIG.WHATSAPP_ENABLED) return;
  
  const message = `🔔 *Nouveau Lead PAC*\n\n` +
                  `👤 ${data.nom}\n` +
                  `📞 ${data.telephone}\n` +
                  `📍 ${data.codePostal}\n` +
                  `🔥 ${data.chauffageActuel}\n\n` +
                  `⏰ Contacter sous 24h`;
  
  const payload = {
    phone: CONFIG.WHATSAPP_PHONE_RECIPIENT,
    message: message
  };
  
  const options = {
    method: 'post',
    contentType: 'application/json',
    headers: {
      'Authorization': 'Bearer ' + CONFIG.WHATSAPP_API_KEY
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };
  
  try {
    const response = UrlFetchApp.fetch(CONFIG.WHATSAPP_API_URL, options);
    Logger.log('WhatsApp envoyé: ' + response.getContentText());
  } catch (error) {
    Logger.log('Erreur WhatsApp: ' + error.toString());
  }
}

// ========================================
// CRÉATION DE LA RÉPONSE HTTP
// ========================================
function createResponse(code, message) {
  return ContentService
    .createTextOutput(JSON.stringify({
      status: code,
      message: message
    }))
    .setMimeType(ContentService.MimeType.JSON);
}

// ========================================
// FONCTION DE TEST (OPTIONNELLE)
// ========================================
function testWebhook() {
  const testData = {
    typeLogement: 'proprietaire-occupant',
    typeResidence: 'maison',
    anciennete: 'plus-15-ans',
    chauffageActuel: 'fioul',
    nbPersonnes: '4',
    revenu: 'modeste',
    codePostal: '75001',
    nom: 'Jean Dupont',
    telephone: '0612345678',
    email: 'test@exemple.fr',
    rgpdConsent: true,
    timestamp: new Date().toISOString(),
    source: 'Test manuel',
    userAgent: 'Test'
  };
  
  const mockEvent = {
    postData: {
      contents: JSON.stringify(testData)
    }
  };
  
  const result = doPost(mockEvent);
  Logger.log(result.getContent());
}
